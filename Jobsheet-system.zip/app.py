from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return "Jobsheet system running!"

@app.route("/create")
def create_jobsheet():
    return render_template("create_jobsheet.html")

if __name__ == "__main__":
    app.run(debug=True)
